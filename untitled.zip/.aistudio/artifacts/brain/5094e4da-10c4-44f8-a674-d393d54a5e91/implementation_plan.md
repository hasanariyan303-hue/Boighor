# বইঘর (Boighor) — Android Reading Tracker & Personal Library

An international-grade, modern, and aesthetic Bengali reading tracker and personal digital library for Android — inspired by Goodreads, StoryGraph, and Apple Books. Built natively using Jetpack Compose (Material 3) and Room Database with full offline persistence, ambient reading soundscapes, quote photo-card sharing, and rich reading analytics.

---

### User Review & Critical Decisions

> [!IMPORTANT]
> The following architectural decisions were aligned via interactive clarification:
> - **Data Persistence**: Device-local Room SQLite database (`boighor_database`) preloaded with 76 classic Bengali and world literature books, with complete JSON/CSV export and import.
> - **Ambient Audio Player**: Atmospheric reading audio generator (rain & quiet library ambience) playable seamlessly during reading sessions.
> - **Shareable Quote & Book Cards**: Compose Canvas/Bitmap renderer generating high-resolution PNG quote & review cards shared via Android `FileProvider` and `ACTION_SEND` Sharesheet.

---

### 1. Overview & Core Concept

**বইঘর (Boighor)** transforms the reading habit into an inspiring, visually captivating journey:
- **76 Classic Literature Preloads**: Immediate access to beloved Bengali literature (Rabindranath, Bibhutibhushan, Satyajit Ray's Feluda, Humayun Ahmed's Himu & Misir Ali, Sunil Gangopadhyay's Kakababu, Saradindu, Arthur Conan Doyle, Agatha Christie, Jules Verne, etc.).
- **2026 Annual Reading Challenge**: Target goal tracking with completion percentage, books read vs remaining, and motivational progress bar.
- **Currently Reading Shelf**: Live page progress slider with real-time percentage and page count updates.
- **Series & Genre Trackers**: Grouped series with superscript edition badges (¹, ², ³...) and genre classification.
- **Quote & Photo Card Studio**: Generate visually stunning book quotes & review cards to share directly to Instagram, Facebook, and WhatsApp.
- **Reading Analytics & Insights**: Total pages read, estimated hours spent reading, top author bars, genre breakdowns, and smart next-read suggestions.

---

### 2. User Experience & Visual Design

#### Navigation & Screen Hierarchy
The app utilizes a modern 5-tab Material 3 bottom navigation structure with edge-to-edge support:
1. **বইয়ের তাক (Bookshelf)**: Hero Reading Challenge card, Currently Reading shelf, search bar with quick clear, filter chips (সব বই, বর্তমানে পড়ছি, সিরিজ, প্রিয় তালিকা, জনরা), sort dropdown, and 3D realistic book spine cards (or list view toggle).
2. **সিরিজ ট্র্যাকার (Series Tracker)**: Categorized series groups (হিমু, মিসির আলি, কাকাবাবু, ফেলুদা, কাঁটায় কাঁটায়, শার্লক হোমস) showing sequential progress.
3. **জনরা (Genres)**: Visual library grouped by literary genres with quick jump chips.
4. **উদ্ধৃতি সংগ্রহ (Quotes & Highlights)**: Inspiring book quotes with direct "কার্ড শেয়ার" button to render social photo cards.
5. **পরিসংখ্যান (Analytics & Insights)**: Stat counters (books, pages, hours, avg rating), author distribution bar charts, genre frequency, and AI/smart recommendation engine.

#### Visual Identity & Styling
- **Aesthetic**: Warm editorial elegance meets contemporary Material 3. Rich book-spine gradients, realistic drop shadows, glassmorphism panels, and smooth spring animations.
- **Color Palette**: Deep Indigo (`#4338CA`), Vibrant Purple (`#7C3AED`), Warm Amber Gold (`#F59E0B`) for ratings and badges, Emerald Green (`#10B981`) for progress indicators, and rich dark surfaces (`#0F172A`).
- **Bengali Typography**: Native Bengali numeral conversion (`toBn()` helper: ০, ১, ২, ৩...), superscripts for series numbers (`¹`, `²`, `³`), and typographic scale optimized for Bengali scripts.
- **Book Cover Generation**: Dynamic vector cover art system generating unique, beautiful dual-tone gradient covers and book motifs based on book title and genre.

---

### 3. Key Product Decisions & Trade-Offs

- **Room Persistence vs In-Memory**:
  - *Chosen Approach*: Room Database with asynchronous Kotlin Coroutines and reactive `Flow<List<BookEntity>>`. Prepopulates 76 books on first run.
  - *Why*: Ensures user ratings, progress, notes, and custom added books survive app reboots and updates without requiring internet connection or account logins.
- **Bitmap Image Generation for Social Sharing**:
  - *Chosen Approach*: Compose layout captured to Android `Bitmap`, compressed to PNG in the application cache directory, and dispatched via `androidx.core.content.FileProvider`.
  - *Why*: Allows crisp, watermark-ready aesthetic images directly sharable to Instagram Stories and messaging apps.
- **Ambient Rain & Library Audio**:
  - *Chosen Approach*: Seamless synthesized loop / AudioTrack audio player with simple play/pause floating control and volume management.
  - *Why*: Zero network dependency, instant start, and zero external large asset downloads.

---

### 4. Technical Architecture & Data Strategy

```
┌────────────────────────────────────────────────────────────────────────┐
│                         Jetpack Compose UI                             │
│ ┌───────────────┐ ┌────────────────┐ ┌──────────────┐ ┌──────────────┐ │
│ │  Bookshelf    │ │ Series Tracker │ │ Quotes Grid  │ │  Analytics   │ │
│ └───────┬───────┘ └───────┬────────┘ └───────┬──────┘ └───────┬──────┘ │
│         └─────────────────┼──────────────────┼────────────────┘        │
│                           ▼                                            │
│                 BoighorViewModel & UiState                             │
│           (StateFlow<BoighorUiState>, User Actions)                    │
│                           │                                            │
│        ┌──────────────────┴──────────────────┐                         │
│        ▼                                     ▼                         │
│  AmbientSoundManager                  BookRepository                   │
│  (Background Ambience)          (Room DAO, Backup/Restore)             │
│                                              │                         │
│                                              ▼                         │
│                                      AppDatabase (Room)                │
│                                 [books] and [bucket_list]              │
└────────────────────────────────────────────────────────────────────────┘
```

#### Core Data Entities

1. **BookEntity**:
   - `id: Int` (Primary Key)
   - `title: String`
   - `author: String`
   - `genre: String`
   - `series: String?`
   - `seriesNum: Int?`
   - `pages: Int`
   - `rating: Float` (IMDb-style decimal 1.0 - 10.0)
   - `favorite: Boolean`
   - `quote: String?`
   - `plot: String`
   - `isCurrentlyReading: Boolean`
   - `currentReadProgress: Int`

2. **BucketBookEntity**:
   - `id: Int` (Primary Key, auto-generate)
   - `title: String`, `author: String`, `pages: Int`, `genre: String`

3. **UserPreferences** (DataStore / SharedPreferences):
   - `annualGoal: Int` (default 100 books for 2026)
   - `currentlyReadingId: Int?`

#### Key Interactive Flows
1. **Book Details & Rating Modal**: Dialog showing book cover, series badge, synopsis, reading progress slider, IMDb rating slider (1.0 to 10.0 with step 0.1), favorite toggle, and personal note/quote editor.
2. **Social Card Sharing**: Click "কার্ড শেয়ার" to preview social card, copy quote text, or generate PNG file and launch Android Sharesheet.
3. **Backup & CSV Export**: Export library to `.csv` or full JSON backup; import backup to restore.
4. **Ambient Sound**: Floating or header audio button toggling calming rain soundscapes with icon animation.

package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.DefaultBooksData
import com.example.util.BengaliNumerals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("বইঘর", appName)
  }

  @Test
  fun `verify initial books count and content`() {
    val initialBooks = DefaultBooksData.getInitialBooks()
    assertEquals(76, initialBooks.size)
    assertEquals("পথের পাঁচালী", initialBooks[0].title)
    assertEquals("হত্যাপুরী", initialBooks[75].title)
  }

  @Test
  fun `verify bengali numerals conversion`() {
    assertEquals("৭৬", BengaliNumerals.toBn(76))
    assertEquals("১০০", BengaliNumerals.toBn(100))
    assertEquals("★ ৯.৬", "★ ${BengaliNumerals.formatRatingBn(9.6f)}")
    assertTrue(BengaliNumerals.getRatingVerdict(9.5f).contains("কালজয়ী"))
  }
}

package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.CloudQueue
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.FormatQuote
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.PieChart
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.BookDetailModal
import com.example.ui.components.BucketAddDialog
import com.example.ui.components.SettingsAndBackupDialog
import com.example.ui.components.ShareCardDialog
import com.example.ui.screens.BookshelfScreen
import com.example.ui.screens.GenresScreen
import com.example.ui.screens.QuotesScreen
import com.example.ui.screens.SeriesScreen
import com.example.ui.screens.StatsScreen
import com.example.ui.theme.AmberRating
import com.example.ui.theme.BoighorTheme
import com.example.ui.theme.EmeraldProgress
import com.example.ui.theme.IndigoPrimary
import com.example.ui.viewmodel.BoighorViewModel
import kotlinx.coroutines.flow.collectLatest

class MainActivity : ComponentActivity() {

    private val viewModel: BoighorViewModel by viewModels()

    @OptIn(ExperimentalMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            var isDarkTheme by remember { mutableStateOf(true) }
            val snackbarHostState = remember { SnackbarHostState() }
            val context = LocalContext.current

            // Collect Toast events
            LaunchedEffect(Unit) {
                viewModel.toastEvent.collectLatest { msg ->
                    Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                }
            }

            BoighorTheme(darkTheme = isDarkTheme) {
                val activeTab by viewModel.activeNavTab.collectAsStateWithLifecycle()
                val isAmbientPlaying by viewModel.ambientPlayer.isPlaying.collectAsStateWithLifecycle()
                val allBooks by viewModel.allBooks.collectAsStateWithLifecycle()
                val bucketBooks by viewModel.allBucketBooks.collectAsStateWithLifecycle()
                val displayedBooks by viewModel.displayedBooks.collectAsStateWithLifecycle()
                val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
                val selectedFilter by viewModel.selectedFilter.collectAsStateWithLifecycle()
                val selectedSort by viewModel.selectedSort.collectAsStateWithLifecycle()
                val isGridView by viewModel.isGridView.collectAsStateWithLifecycle()
                val readingGoal by viewModel.readingGoal.collectAsStateWithLifecycle()

                // Dialog states
                val modalBook by viewModel.selectedBookForModal.collectAsStateWithLifecycle()
                val shareBook by viewModel.selectedBookForShare.collectAsStateWithLifecycle()
                val showSettings by viewModel.showSettingsDialog.collectAsStateWithLifecycle()
                val settingsTab by viewModel.settingsTab.collectAsStateWithLifecycle()
                val showBucketAdd by viewModel.showBucketAddDialog.collectAsStateWithLifecycle()

                // BackHandler
                BackHandler(enabled = activeTab != "shelf") {
                    viewModel.setActiveNavTab("shelf")
                }

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    snackbarHost = { SnackbarHost(snackbarHostState) },
                    topBar = {
                        TopAppBar(
                            title = {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(34.dp)
                                            .background(
                                                Brush.linearGradient(
                                                    listOf(Color(0xFF6366F1), Color(0xFFA855F7))
                                                ),
                                                RoundedCornerShape(10.dp)
                                            ),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Bookmark,
                                            contentDescription = "Logo",
                                            tint = Color.White,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }

                                    Spacer(modifier = Modifier.width(8.dp))

                                    Column {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(
                                                text = "বইঘর",
                                                fontWeight = FontWeight.ExtraBold,
                                                fontSize = 18.sp,
                                                color = MaterialTheme.colorScheme.onSurface
                                            )
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Box(
                                                modifier = Modifier
                                                    .background(Color(0x206366F1), RoundedCornerShape(4.dp))
                                                    .padding(horizontal = 4.dp, vertical = 1.dp)
                                            ) {
                                                Text(
                                                    text = "PRO",
                                                    fontSize = 8.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = IndigoPrimary
                                                )
                                            }
                                        }
                                        Text(
                                            text = "ব্যক্তিগত পাঠাগার",
                                            fontSize = 9.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            },
                            actions = {
                                // Rain Ambience Button
                                Button(
                                    onClick = { viewModel.toggleAmbientSound() },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (isAmbientPlaying) Color(0x336366F1) else MaterialTheme.colorScheme.surfaceVariant
                                    ),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier
                                        .height(34.dp)
                                        .testTag("ambience_toggle_button")
                                ) {
                                    Icon(
                                        imageVector = if (isAmbientPlaying) Icons.Default.WaterDrop else Icons.Default.CloudQueue,
                                        contentDescription = "Ambience",
                                        tint = if (isAmbientPlaying) IndigoPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = if (isAmbientPlaying) "বৃষ্টি চলছে" else "বৃষ্টির সুর",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isAmbientPlaying) IndigoPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }

                                Spacer(modifier = Modifier.width(4.dp))

                                // Add Book Button
                                IconButton(
                                    onClick = { viewModel.openSettingsDialog("add") },
                                    modifier = Modifier.testTag("add_book_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Add,
                                        contentDescription = "Add Book",
                                        tint = IndigoPrimary
                                    )
                                }

                                // Settings Button
                                IconButton(
                                    onClick = { viewModel.openSettingsDialog("edit") },
                                    modifier = Modifier.testTag("settings_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Settings,
                                        contentDescription = "Settings",
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }

                                // Dark / Light Mode Toggle
                                IconButton(
                                    onClick = { isDarkTheme = !isDarkTheme },
                                    modifier = Modifier.testTag("theme_toggle_button")
                                ) {
                                    Icon(
                                        imageVector = if (isDarkTheme) Icons.Default.LightMode else Icons.Default.DarkMode,
                                        contentDescription = "Toggle Theme",
                                        tint = if (isDarkTheme) AmberRating else Color.Gray
                                    )
                                }
                            },
                            colors = TopAppBarDefaults.topAppBarColors(
                                containerColor = MaterialTheme.colorScheme.surface
                            )
                        )
                    },
                    bottomBar = {
                        NavigationBar(
                            containerColor = MaterialTheme.colorScheme.surface,
                            tonalElevation = 4.dp
                        ) {
                            NavigationBarItem(
                                selected = activeTab == "shelf",
                                onClick = { viewModel.setActiveNavTab("shelf") },
                                icon = { Icon(Icons.Default.MenuBook, contentDescription = "Bookshelf") },
                                label = { Text("বইয়ের তাক", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = IndigoPrimary,
                                    selectedTextColor = IndigoPrimary,
                                    indicatorColor = Color(0x206366F1)
                                )
                            )
                            NavigationBarItem(
                                selected = activeTab == "series",
                                onClick = { viewModel.setActiveNavTab("series") },
                                icon = { Icon(Icons.Default.Layers, contentDescription = "Series") },
                                label = { Text("সিরিজ", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = IndigoPrimary,
                                    selectedTextColor = IndigoPrimary,
                                    indicatorColor = Color(0x206366F1)
                                )
                            )
                            NavigationBarItem(
                                selected = activeTab == "genres",
                                onClick = { viewModel.setActiveNavTab("genres") },
                                icon = { Icon(Icons.Default.Explore, contentDescription = "Genres") },
                                label = { Text("জনরা", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = IndigoPrimary,
                                    selectedTextColor = IndigoPrimary,
                                    indicatorColor = Color(0x206366F1)
                                )
                            )
                            NavigationBarItem(
                                selected = activeTab == "quotes",
                                onClick = { viewModel.setActiveNavTab("quotes") },
                                icon = { Icon(Icons.Default.FormatQuote, contentDescription = "Quotes") },
                                label = { Text("উদ্ধৃতি", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = IndigoPrimary,
                                    selectedTextColor = IndigoPrimary,
                                    indicatorColor = Color(0x206366F1)
                                )
                            )
                            NavigationBarItem(
                                selected = activeTab == "stats",
                                onClick = { viewModel.setActiveNavTab("stats") },
                                icon = { Icon(Icons.Default.PieChart, contentDescription = "Stats") },
                                label = { Text("পরিসংখ্যান", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = IndigoPrimary,
                                    selectedTextColor = IndigoPrimary,
                                    indicatorColor = Color(0x206366F1)
                                )
                            )
                        }
                    }
                ) { paddingValues ->
                    Box(modifier = Modifier.padding(paddingValues)) {
                        when (activeTab) {
                            "shelf" -> BookshelfScreen(
                                viewModel = viewModel,
                                books = displayedBooks,
                                allBooks = allBooks,
                                bucketBooks = bucketBooks,
                                searchQuery = searchQuery,
                                selectedFilter = selectedFilter,
                                selectedSort = selectedSort,
                                isGridView = isGridView,
                                readingGoal = readingGoal
                            )
                            "series" -> SeriesScreen(
                                books = allBooks,
                                onBookClick = { viewModel.openBookModal(it) }
                            )
                            "genres" -> GenresScreen(
                                books = allBooks,
                                onBookClick = { viewModel.openBookModal(it) }
                            )
                            "quotes" -> QuotesScreen(
                                books = allBooks,
                                onShareCard = { viewModel.openShareModal(it) },
                                onSaveQuote = { book, q -> viewModel.updateBookDetails(book.copy(quote = q)) }
                            )
                            "stats" -> StatsScreen(
                                books = allBooks,
                                onRefreshRecommendations = {
                                    viewModel.sendToast("আপনার পাঠরুচির ভিত্তিতে ৩টি বই বাছাই করা হয়েছে!")
                                }
                            )
                        }
                    }

                    // Dialogs
                    modalBook?.let { book ->
                        BookDetailModal(
                            book = book,
                            onDismiss = { viewModel.closeBookModal() },
                            onSave = { updated -> viewModel.updateBookDetails(updated) },
                            onToggleFavorite = { viewModel.toggleFavorite(book.id) },
                            onStartReading = { viewModel.setCurrentlyReading(book.id) },
                            onShareCard = { viewModel.openShareModal(book) }
                        )
                    }

                    shareBook?.let { book ->
                        ShareCardDialog(
                            book = book,
                            onDismiss = { viewModel.closeShareModal() }
                        )
                    }

                    if (showSettings) {
                        SettingsAndBackupDialog(
                            viewModel = viewModel,
                            books = allBooks,
                            initialTab = settingsTab,
                            onDismiss = { viewModel.closeSettingsDialog() }
                        )
                    }

                    if (showBucketAdd) {
                        BucketAddDialog(
                            onDismiss = { viewModel.closeBucketAddDialog() },
                            onAdd = { title, author, pages ->
                                viewModel.addBucketBook(title, author, pages)
                            }
                        )
                    }
                }
            }
        }
    }
}

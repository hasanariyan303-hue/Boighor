package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val IndigoPrimary = Color(0xFF4F46E5)
val IndigoLight = Color(0xFF6366F1)
val IndigoDark = Color(0xFF3730A3)

val PurpleAccent = Color(0xFF8B5CF6)
val AmberRating = Color(0xFFF59E0B)
val EmeraldProgress = Color(0xFF10B981)
val RoseHeart = Color(0xFFF43F5E)

// Dark Theme Surfaces
val DarkBg = Color(0xFF090D16)
val DarkSurface = Color(0xFF0F172A)
val DarkSurfaceVariant = Color(0xFF1E293B)
val DarkBorder = Color(0xFF334155)

// Light Theme Surfaces
val LightBg = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFF1F5F9)
val LightBorder = Color(0xFFE2E8F0)

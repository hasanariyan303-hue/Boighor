package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.audio.AmbientSoundPlayer
import com.example.data.local.BoighorDatabase
import com.example.data.local.BookEntity
import com.example.data.local.BucketBookEntity
import com.example.data.repository.BoighorRepository
import com.example.util.BengaliNumerals
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class BoighorViewModel(application: Application) : AndroidViewModel(application) {

    private val database = BoighorDatabase.getDatabase(application, viewModelScope)
    val repository = BoighorRepository(database.bookDao())
    val ambientPlayer = AmbientSoundPlayer()

    val allBooks = repository.allBooks.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val allBucketBooks = repository.allBucketBooks.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    private val _activeNavTab = MutableStateFlow("shelf")
    val activeNavTab: StateFlow<String> = _activeNavTab.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedFilter = MutableStateFlow("সব বই")
    val selectedFilter: StateFlow<String> = _selectedFilter.asStateFlow()

    private val _selectedSort = MutableStateFlow("id-asc")
    val selectedSort: StateFlow<String> = _selectedSort.asStateFlow()

    private val _isGridView = MutableStateFlow(true)
    val isGridView: StateFlow<Boolean> = _isGridView.asStateFlow()

    private val _readingGoal = MutableStateFlow(100)
    val readingGoal: StateFlow<Int> = _readingGoal.asStateFlow()

    private val _selectedBookForModal = MutableStateFlow<BookEntity?>(null)
    val selectedBookForModal: StateFlow<BookEntity?> = _selectedBookForModal.asStateFlow()

    private val _selectedBookForShare = MutableStateFlow<BookEntity?>(null)
    val selectedBookForShare: StateFlow<BookEntity?> = _selectedBookForShare.asStateFlow()

    private val _showSettingsDialog = MutableStateFlow(false)
    val showSettingsDialog: StateFlow<Boolean> = _showSettingsDialog.asStateFlow()

    private val _settingsTab = MutableStateFlow("edit")
    val settingsTab: StateFlow<String> = _settingsTab.asStateFlow()

    private val _showBucketAddDialog = MutableStateFlow(false)
    val showBucketAddDialog: StateFlow<Boolean> = _showBucketAddDialog.asStateFlow()

    private val _toastEvent = MutableSharedFlow<String>()
    val toastEvent: SharedFlow<String> = _toastEvent.asSharedFlow()

    init {
        viewModelScope.launch {
            repository.ensureInitialData()
        }
    }

    // Filtered books stream
    val displayedBooks: StateFlow<List<BookEntity>> = combine(
        allBooks,
        _searchQuery,
        _selectedFilter,
        _selectedSort
    ) { books, query, filter, sort ->
        var list = books.filter { book ->
            val matchesFilter = when (filter) {
                "সব বই" -> true
                "বর্তমানে পড়ছি" -> book.isCurrentlyReading
                "সিরিজ বই" -> !book.series.isNullOrEmpty()
                "প্রিয় তালিকা" -> book.favorite
                "হুমায়ূন আহমেদ" -> book.author.contains("হুমায়ূন আহমেদ")
                "সুনীল গঙ্গোপাধ্যায়" -> book.author.contains("সুনীল গঙ্গোপাধ্যায়")
                else -> book.genre == filter
            }

            if (!matchesFilter) return@filter false

            if (query.isNotBlank()) {
                val q = query.trim().lowercase()
                val matchTitle = book.title.lowercase().contains(q)
                val matchAuthor = book.author.lowercase().contains(q)
                val matchGenre = book.genre.lowercase().contains(q)
                val matchId = book.id.toString() == q.replace("#", "")
                val matchBnId = BengaliNumerals.toBn(book.id) == q.replace("#", "")
                matchTitle || matchAuthor || matchGenre || matchId || matchBnId
            } else {
                true
            }
        }

        list = when (sort) {
            "id-asc" -> list.sortedBy { it.id }
            "id-desc" -> list.sortedByDescending { it.id }
            "rating-desc" -> list.sortedByDescending { it.rating }
            "rating-asc" -> list.sortedBy { it.rating }
            "pages-desc" -> list.sortedByDescending { it.pages }
            "pages-asc" -> list.sortedBy { it.pages }
            "title" -> list.sortedBy { it.title }
            "author" -> list.sortedBy { it.author }
            else -> list.sortedBy { it.id }
        }

        list
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    fun setActiveNavTab(tab: String) {
        _activeNavTab.value = tab
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setSelectedFilter(filter: String) {
        _selectedFilter.value = filter
    }

    fun setSelectedSort(sort: String) {
        _selectedSort.value = sort
    }

    fun toggleViewMode() {
        _isGridView.value = !_isGridView.value
    }

    fun setReadingGoal(goal: Int) {
        _readingGoal.value = goal.coerceAtLeast(1)
        sendToast("২০২৬ পঠন লক্ষ্যমাত্রা ${BengaliNumerals.toBn(_readingGoal.value)}টি বই নির্ধারণ করা হয়েছে!")
    }

    fun openBookModal(book: BookEntity) {
        _selectedBookForModal.value = book
    }

    fun closeBookModal() {
        _selectedBookForModal.value = null
    }

    fun openShareModal(book: BookEntity) {
        _selectedBookForShare.value = book
    }

    fun closeShareModal() {
        _selectedBookForShare.value = null
    }

    fun openSettingsDialog(tab: String = "edit") {
        _settingsTab.value = tab
        _showSettingsDialog.value = true
    }

    fun closeSettingsDialog() {
        _showSettingsDialog.value = false
    }

    fun setSettingsTab(tab: String) {
        _settingsTab.value = tab
    }

    fun openBucketAddDialog() {
        _showBucketAddDialog.value = true
    }

    fun closeBucketAddDialog() {
        _showBucketAddDialog.value = false
    }

    fun setCurrentlyReading(bookId: Int) {
        viewModelScope.launch {
            repository.setCurrentlyReading(bookId)
            val updated = repository.getBookById(bookId)
            _selectedBookForModal.value = updated
            sendToast("বইটি 'বর্তমানে পড়ছি' তালিকায় যুক্ত হয়েছে!")
        }
    }

    fun updateBookProgress(bookId: Int, progress: Int) {
        viewModelScope.launch {
            repository.updateBookProgress(bookId, progress)
            val current = _selectedBookForModal.value
            if (current?.id == bookId) {
                _selectedBookForModal.value = current.copy(currentProgress = progress)
            }
        }
    }

    fun toggleFavorite(bookId: Int) {
        viewModelScope.launch {
            repository.toggleFavorite(bookId)
            val current = _selectedBookForModal.value
            if (current?.id == bookId) {
                _selectedBookForModal.value = current.copy(favorite = !current.favorite)
            }
            val book = repository.getBookById(bookId)
            if (book?.favorite == true) {
                sendToast("\"${book.title}\" প্রিয় তালিকায় যুক্ত হয়েছে!")
            } else {
                sendToast("প্রিয় তালিকা থেকে সরানো হয়েছে।")
            }
        }
    }

    fun updateBookDetails(book: BookEntity) {
        viewModelScope.launch {
            repository.updateBook(book)
            _selectedBookForModal.value = book
            sendToast("\"${book.title}\" সংরক্ষিত হয়েছে!")
        }
    }

    fun addNewBook(
        title: String,
        author: String,
        genre: String,
        series: String?,
        seriesNum: String?,
        pages: Int
    ) {
        viewModelScope.launch {
            val count = allBooks.value.size
            val newBook = BookEntity(
                id = count + 1,
                title = title.trim(),
                author = author.trim(),
                genre = genre,
                series = series?.trim()?.ifEmpty { null },
                seriesNum = seriesNum?.trim()?.ifEmpty { null },
                pages = pages,
                rating = 9.0f,
                favorite = false,
                plot = "\"$title\" (~ $author) গ্রন্থটি আপনার ব্যক্তিগত বইঘরে যুক্ত হয়েছে।"
            )
            repository.insertBook(newBook)
            closeSettingsDialog()
            sendToast("\"$title\" লাইব্রেরিতে যুক্ত হয়েছে!")
        }
    }

    fun deleteBook(bookId: Int) {
        viewModelScope.launch {
            repository.deleteBookById(bookId)
            if (_selectedBookForModal.value?.id == bookId) {
                _selectedBookForModal.value = null
            }
            sendToast("বইটি মুছে ফেলা হয়েছে।")
        }
    }

    fun addBucketBook(title: String, author: String, pages: Int) {
        viewModelScope.launch {
            val bucket = BucketBookEntity(
                title = title.trim(),
                author = author.trim(),
                pages = pages
            )
            repository.insertBucketBook(bucket)
            closeBucketAddDialog()
            _selectedFilter.value = "বাকেট লিস্ট"
            sendToast("\"$title\" বাকেট লিস্টে যুক্ত হয়েছে!")
        }
    }

    fun deleteBucketBook(id: Long) {
        viewModelScope.launch {
            repository.deleteBucketBookById(id)
            sendToast("বাকেট লিস্ট থেকে সরানো হয়েছে।")
        }
    }

    fun addBucketBookToLibrary(item: BucketBookEntity) {
        viewModelScope.launch {
            val count = allBooks.value.size
            val newBook = BookEntity(
                id = count + 1,
                title = item.title,
                author = item.author,
                genre = item.genre,
                pages = item.pages,
                rating = item.rating,
                isCurrentlyReading = true,
                plot = "\"${item.title}\" বাকেট লিস্ট থেকে মূল পাঠাগারে যুক্ত হয়েছে।"
            )
            repository.insertBook(newBook)
            repository.deleteBucketBookById(item.id)
            sendToast("\"${item.title}\" পাঠাগারে যুক্ত করে পড়া শুরু হয়েছে!")
        }
    }

    fun toggleAmbientSound() {
        ambientPlayer.toggle { isPlaying ->
            if (isPlaying) {
                sendToast("মৃদু বৃষ্টির সুর চালু হয়েছে। শুভ পাঠ!")
            } else {
                sendToast("অ্যাম্বিয়েন্স বন্ধ করা হয়েছে।")
            }
        }
    }

    fun sendToast(msg: String) {
        viewModelScope.launch {
            _toastEvent.emit(msg)
        }
    }

    override fun onCleared() {
        super.onCleared()
        ambientPlayer.stop()
    }
}

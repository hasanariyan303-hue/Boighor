package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.BookEntity
import com.example.data.local.BucketBookEntity
import com.example.ui.components.BookCoverView
import com.example.ui.components.CurrentlyReadingWidget
import com.example.ui.components.ReadingChallengeCard
import com.example.ui.theme.AmberRating
import com.example.ui.theme.EmeraldProgress
import com.example.ui.theme.IndigoPrimary
import com.example.ui.theme.RoseHeart
import com.example.ui.viewmodel.BoighorViewModel
import com.example.util.BengaliNumerals

@Composable
fun BookshelfScreen(
    viewModel: BoighorViewModel,
    books: List<BookEntity>,
    allBooks: List<BookEntity>,
    bucketBooks: List<BucketBookEntity>,
    searchQuery: String,
    selectedFilter: String,
    selectedSort: String,
    isGridView: Boolean,
    readingGoal: Int,
    modifier: Modifier = Modifier
) {
    var sortMenuExpanded by remember { mutableStateOf(false) }

    val filterList = listOf(
        "সব বই",
        "বর্তমানে পড়ছি",
        "বাকেট লিস্ট",
        "সিরিজ বই",
        "প্রিয় তালিকা",
        "হুমায়ূন আহমেদ",
        "সুনীল গঙ্গোপাধ্যায়",
        "উপন্যাস",
        "রহস্য ও গোয়েন্দা",
        "অ্যাডভেঞ্চার"
    )

    val currentlyReadingBook = allBooks.find { it.isCurrentlyReading } ?: allBooks.firstOrNull()

    Column(
        modifier = modifier
            .fillMaxSize()
            .testTag("bookshelf_screen")
    ) {
        if (selectedFilter == "বাকেট লিস্ট") {
            // Bucket List View
            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    // Bucket List Banner
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0x20F59E0B))
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text(
                                text = "📋 আমার বাকেট লিস্ট (ভবিষ্যতে পড়ার ইচ্ছা)",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "বইগুলো পড়া শুরু করলে 'পড়ছি' চাপলেই সরাসরি মূল তালিকায় যুক্ত হয়ে যাবে।",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Button(
                                onClick = { viewModel.openBucketAddDialog() },
                                colors = ButtonDefaults.buttonColors(containerColor = AmberRating),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.height(36.dp)
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp), tint = Color.Black)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("বাকেট লিস্টে বই যোগ করুন", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.Black)
                            }
                        }
                    }
                }

                // Filter Chips
                item {
                    FilterChipsRow(
                        filters = filterList,
                        selected = selectedFilter,
                        onSelect = { viewModel.setSelectedFilter(it) }
                    )
                }

                if (bucketBooks.isEmpty()) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 40.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "বাকেট লিস্টে এখনও কোনো বই যোগ করা হয়নি।",
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                } else {
                    items(bucketBooks, key = { it.id }) { item ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = item.title,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = "~ ${item.author} • ${BengaliNumerals.formatPageCountBadge(item.pages)}",
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }

                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Button(
                                        onClick = { viewModel.addBucketBookToLibrary(item) },
                                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldProgress),
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.height(32.dp)
                                    ) {
                                        Text("পড়া শুরু", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    }
                                    Spacer(modifier = Modifier.width(6.dp))
                                    IconButton(
                                        onClick = { viewModel.deleteBucketBook(item.id) },
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(Icons.Default.Clear, contentDescription = "Remove", tint = Color.Gray, modifier = Modifier.size(16.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            // Main Bookshelf Grid / List
            LazyVerticalGrid(
                columns = GridCells.Fixed(if (isGridView) 3 else 1),
                contentPadding = PaddingValues(16.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                // Header 1: Reading Challenge
                item(span = { GridItemSpan(maxLineSpan) }) {
                    ReadingChallengeCard(
                        totalBooksRead = allBooks.size,
                        goal = readingGoal,
                        onGoalChange = { viewModel.setReadingGoal(it) }
                    )
                }

                // Header 2: Currently Reading
                item(span = { GridItemSpan(maxLineSpan) }) {
                    CurrentlyReadingWidget(
                        book = currentlyReadingBook,
                        onProgressChange = { progress ->
                            currentlyReadingBook?.let { viewModel.updateBookProgress(it.id, progress) }
                        },
                        onClick = {
                            currentlyReadingBook?.let { viewModel.openBookModal(it) }
                        }
                    )
                }

                // Controls: Search, Sort & View Mode
                item(span = { GridItemSpan(maxLineSpan) }) {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedTextField(
                                value = searchQuery,
                                onValueChange = { viewModel.setSearchQuery(it) },
                                placeholder = { Text("বইয়ের নাম, লেখক বা #আইডি...", fontSize = 12.sp) },
                                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(18.dp)) },
                                trailingIcon = {
                                    if (searchQuery.isNotEmpty()) {
                                        IconButton(onClick = { viewModel.setSearchQuery("") }) {
                                            Icon(Icons.Default.Clear, contentDescription = "Clear", modifier = Modifier.size(16.dp))
                                        }
                                    }
                                },
                                singleLine = true,
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                                    .testTag("search_input")
                            )

                            Spacer(modifier = Modifier.width(8.dp))

                            // Sort dropdown button
                            Box {
                                OutlinedButton(
                                    onClick = { sortMenuExpanded = true },
                                    modifier = Modifier.height(48.dp),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Text(
                                        text = when (selectedSort) {
                                            "rating-desc" -> "রেটিং (বেশি)"
                                            "pages-desc" -> "পৃষ্ঠা (বেশি)"
                                            "title" -> "নাম"
                                            else -> "ক্রমিক"
                                        },
                                        fontSize = 11.sp
                                    )
                                    Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                                }

                                DropdownMenu(
                                    expanded = sortMenuExpanded,
                                    onDismissRequest = { sortMenuExpanded = false }
                                ) {
                                    DropdownMenuItem(
                                        text = { Text("ক্রমিক (১ - ৭৬)") },
                                        onClick = { viewModel.setSelectedSort("id-asc"); sortMenuExpanded = false }
                                    )
                                    DropdownMenuItem(
                                        text = { Text("নতুন পড়া আগে (৭৬ - ১)") },
                                        onClick = { viewModel.setSelectedSort("id-desc"); sortMenuExpanded = false }
                                    )
                                    DropdownMenuItem(
                                        text = { Text("রেটিং (বেশি → কম)") },
                                        onClick = { viewModel.setSelectedSort("rating-desc"); sortMenuExpanded = false }
                                    )
                                    DropdownMenuItem(
                                        text = { Text("পৃষ্ঠা সংখ্যা (বেশি → কম)") },
                                        onClick = { viewModel.setSelectedSort("pages-desc"); sortMenuExpanded = false }
                                    )
                                    DropdownMenuItem(
                                        text = { Text("বইয়ের নাম (ক - হ)") },
                                        onClick = { viewModel.setSelectedSort("title"); sortMenuExpanded = false }
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.width(6.dp))

                            // Grid/List toggle
                            IconButton(
                                onClick = { viewModel.toggleViewMode() },
                                modifier = Modifier
                                    .size(46.dp)
                                    .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(12.dp))
                            ) {
                                Icon(
                                    imageVector = if (isGridView) Icons.Default.List else Icons.Default.GridView,
                                    contentDescription = "Toggle View",
                                    tint = IndigoPrimary
                                )
                            }
                        }

                        // Filter Chips
                        FilterChipsRow(
                            filters = filterList,
                            selected = selectedFilter,
                            onSelect = { viewModel.setSelectedFilter(it) }
                        )

                        // Info status
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "${BengaliNumerals.toBn(books.size)}টি বই প্রদর্শিত",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = IndigoPrimary
                            )
                            Text(
                                text = "কভারে ক্লিক করে বিস্তারিত পড়ুন",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                // Books Items
                if (isGridView) {
                    items(books, key = { it.id }) { book ->
                        BookCoverView(
                            book = book,
                            onClick = { viewModel.openBookModal(book) },
                            onFavoriteToggle = { viewModel.toggleFavorite(book.id) }
                        )
                    }
                } else {
                    items(books, key = { it.id }) { book ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { viewModel.openBookModal(book) },
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    modifier = Modifier.weight(1f),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "#${BengaliNumerals.toBn(book.id)}",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.width(32.dp)
                                    )
                                    Column {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(
                                                text = book.title,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 14.sp,
                                                color = MaterialTheme.colorScheme.onSurface
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Box(
                                                modifier = Modifier
                                                    .background(Color(0x204F46E5), RoundedCornerShape(4.dp))
                                                    .padding(horizontal = 4.dp, vertical = 1.dp)
                                            ) {
                                                Text(book.genre, fontSize = 9.sp, color = IndigoPrimary)
                                            }
                                        }
                                        Text(
                                            text = "~ ${book.author} ${if (!book.series.isNullOrEmpty()) "• [${book.series}]" else ""}",
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }

                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = "★ ${BengaliNumerals.formatRatingBn(book.rating)}",
                                        color = AmberRating,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    IconButton(
                                        onClick = { viewModel.toggleFavorite(book.id) },
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(
                                            imageVector = if (book.favorite) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                                            contentDescription = "Favorite",
                                            tint = if (book.favorite) RoseHeart else Color.Gray,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun FilterChipsRow(
    filters: List<String>,
    selected: String,
    onSelect: (String) -> Unit
) {
    LazyRow(
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        items(filters) { f ->
            val isSelected = selected == f
            FilterChip(
                selected = isSelected,
                onClick = { onSelect(f) },
                label = { Text(f, fontSize = 11.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal) },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = IndigoPrimary,
                    selectedLabelColor = Color.White
                )
            )
        }
    }
}

package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.local.BookEntity
import com.example.ui.theme.AmberRating
import com.example.ui.theme.EmeraldProgress
import com.example.ui.theme.IndigoPrimary
import com.example.ui.theme.RoseHeart
import com.example.util.BengaliNumerals

@Composable
fun BookDetailModal(
    book: BookEntity,
    onDismiss: () -> Unit,
    onSave: (BookEntity) -> Unit,
    onToggleFavorite: () -> Unit,
    onStartReading: () -> Unit,
    onShareCard: () -> Unit
) {
    var rating by remember(book.id) { mutableFloatStateOf(book.rating) }
    var pagesText by remember(book.id) { mutableStateOf(if (book.pages > 0) book.pages.toString() else "") }
    var quoteText by remember(book.id) { mutableStateOf(book.quote ?: "") }
    var currentProgress by remember(book.id) { mutableIntStateOf(book.currentProgress) }
    var showDetailedStory by remember(book.id) { mutableStateOf(false) }

    val totalPages = pagesText.toIntOrNull() ?: if (book.pages > 0) book.pages else 250

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .padding(16.dp)
                .fillMaxWidth()
                .heightIn(max = 700.dp)
                .testTag("book_detail_dialog"),
            shape = RoundedCornerShape(24.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 8.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                // Header with Book Gradient
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.verticalGradient(
                                listOf(Color(0xFF3730A3), Color(0xFF1E1B4B))
                            )
                        )
                        .padding(16.dp)
                ) {
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .size(32.dp)
                            .background(Color(0x55000000), CircleShape)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(end = 36.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Mini 3D Cover Preview
                        Box(
                            modifier = Modifier
                                .width(90.dp)
                                .aspectRatio(0.66f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFF4338CA)),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.padding(6.dp)
                            ) {
                                Text(
                                    text = "#${BengaliNumerals.toBn(book.id)}",
                                    color = Color.White,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = book.title,
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 2
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(14.dp))

                        Column {
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Box(
                                    modifier = Modifier
                                        .background(Color(0x33FFFFFF), RoundedCornerShape(6.dp))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = book.genre,
                                        color = Color.White,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                Box(
                                    modifier = Modifier
                                        .background(Color(0x33F59E0B), RoundedCornerShape(6.dp))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = BengaliNumerals.formatPageCountBadge(book.pages),
                                        color = AmberRating,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(4.dp))

                            Text(
                                text = book.title,
                                color = Color.White,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold
                            )

                            Text(
                                text = "~ ${book.author}",
                                color = Color(0xFFCBD5E1),
                                fontSize = 12.sp
                            )

                            if (!book.series.isNullOrEmpty()) {
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "📚 ${book.series} ${BengaliNumerals.toSup(book.seriesNum)}",
                                    color = Color(0xFFFDE047),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(
                                    onClick = onStartReading,
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (book.isCurrentlyReading) EmeraldProgress else Color(0x44FFFFFF)
                                    ),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.height(32.dp)
                                ) {
                                    Text(
                                        text = if (book.isCurrentlyReading) "পড়ছি" else "পড়া শুরু",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }

                                Button(
                                    onClick = onShareCard,
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0x33000000)),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.height(32.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Share,
                                        contentDescription = "Share",
                                        tint = Color.White,
                                        modifier = Modifier.size(12.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(text = "কার্ড শেয়ার", fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }

                // Body Section
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    // Reading Progress Slider if Currently Reading
                    if (book.isCurrentlyReading) {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color(0x1510B981)),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                val pct = ((currentProgress.toFloat() / totalPages) * 100).toInt()
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "পড়ার প্রগ্রেস ট্র্যাকার",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = EmeraldProgress
                                    )
                                    Text(
                                        text = "${BengaliNumerals.toBn(currentProgress)} / ${BengaliNumerals.toBn(totalPages)} পৃষ্ঠা (${BengaliNumerals.toBn(pct)}%)",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = EmeraldProgress
                                    )
                                }
                                Slider(
                                    value = currentProgress.toFloat(),
                                    onValueChange = { currentProgress = it.toInt() },
                                    valueRange = 0f..totalPages.toFloat(),
                                    colors = SliderDefaults.colors(
                                        thumbColor = EmeraldProgress,
                                        activeTrackColor = EmeraldProgress
                                    )
                                )
                            }
                        }
                    }

                    // Synopsis Card
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                        ),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "মূল কাহিনী ও প্রেক্ষাপট",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = IndigoPrimary
                                )
                                TextButton(
                                    onClick = { showDetailedStory = !showDetailedStory }
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.AutoAwesome,
                                        contentDescription = "AI",
                                        tint = AmberRating,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = if (showDetailedStory) "সংক্ষেপ করুন" else "বিস্তারিত কাহিনী (AI)",
                                        fontSize = 11.sp,
                                        color = IndigoPrimary
                                    )
                                }
                            }
                            Text(
                                text = book.plot.ifEmpty { "${book.title} (~ ${book.author}) গ্রন্থটির প্লট ও বর্ণনা সংগৃহীত রয়েছে।" },
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurface,
                                lineHeight = 18.sp
                            )

                            if (showDetailedStory) {
                                HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = Color(0x22000000))
                                Text(
                                    text = "✨ চরিত্র ও প্রেক্ষাপট বিশ্লেষণ:\nএই গ্রন্থের চরিত্রগুলো অসাধারণ মানবিক ও দার্শনিক গভীরতা সম্পন্ন। লেখকের নিজস্ব ধারা ও সাহিত্যরসের সমন্বয়ে রচিত কাহিনীটি পাঠকদের এক অনন্য জগতে নিয়ে যায়।",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    lineHeight = 16.sp
                                )
                            }
                        }
                    }

                    // IMDb-Style Decimal Rating Slider & Favorite Button
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                        ),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .background(AmberRating, RoundedCornerShape(8.dp))
                                            .padding(horizontal = 8.dp, vertical = 4.dp)
                                    ) {
                                        Text(
                                            text = "★ ${BengaliNumerals.formatRatingBn(rating)}/১০",
                                            color = Color.Black,
                                            fontWeight = FontWeight.ExtraBold,
                                            fontSize = 14.sp
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Column {
                                        Text(
                                            text = "আপনার রেটিং (IMDb স্টাইল)",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                        Text(
                                            text = BengaliNumerals.getRatingVerdict(rating),
                                            fontSize = 10.sp,
                                            color = AmberRating,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                    }
                                }

                                IconButton(
                                    onClick = onToggleFavorite,
                                    modifier = Modifier
                                        .size(36.dp)
                                        .background(if (book.favorite) Color(0x25F43F5E) else Color(0x15000000), CircleShape)
                                ) {
                                    Icon(
                                        imageVector = if (book.favorite) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                                        contentDescription = "Favorite",
                                        tint = if (book.favorite) RoseHeart else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                TextButton(
                                    onClick = { rating = (rating - 0.1f).coerceIn(1.0f, 10.0f) }
                                ) {
                                    Text("-", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                                }
                                Slider(
                                    value = rating,
                                    onValueChange = { rating = ((it * 10).toInt() / 10f) },
                                    valueRange = 1.0f..10.0f,
                                    modifier = Modifier.weight(1f),
                                    colors = SliderDefaults.colors(
                                        thumbColor = AmberRating,
                                        activeTrackColor = AmberRating
                                    )
                                )
                                TextButton(
                                    onClick = { rating = (rating + 0.1f).coerceIn(1.0f, 10.0f) }
                                ) {
                                    Text("+", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    // Pages Input and Personal Reflection / Quote Text
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = pagesText,
                            onValueChange = { pagesText = it.filter { ch -> ch.isDigit() } },
                            label = { Text("পৃষ্ঠা") },
                            modifier = Modifier.width(90.dp),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = quoteText,
                            onValueChange = { quoteText = it },
                            label = { Text("স্মরণীয় উক্তি / ব্যক্তিগত মতামত") },
                            modifier = Modifier.weight(1f),
                            maxLines = 3
                        )
                    }

                    // Action Buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedButton(onClick = onDismiss) {
                            Text("বাতিল")
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                val p = pagesText.toIntOrNull() ?: book.pages
                                onSave(
                                    book.copy(
                                        rating = rating,
                                        pages = p,
                                        quote = quoteText.trim().ifEmpty { null },
                                        currentProgress = currentProgress
                                    )
                                )
                                onDismiss()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = IndigoPrimary)
                        ) {
                            Text("সংরক্ষণ করুন")
                        }
                    }
                }
            }
        }
    }
}

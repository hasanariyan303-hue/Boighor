package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.BookEntity
import com.example.ui.theme.AmberRating
import com.example.ui.theme.EmeraldProgress
import com.example.ui.theme.IndigoPrimary
import com.example.ui.theme.PurpleAccent
import com.example.util.BengaliNumerals

@Composable
fun StatsScreen(
    books: List<BookEntity>,
    onRefreshRecommendations: () -> Unit,
    modifier: Modifier = Modifier
) {
    val totalBooks = books.size
    val totalPages = books.sumOf { it.pages }
    val approxReadingHours = (totalPages / 50).coerceAtLeast(1) // 50 pages / hour pace
    val uniqueAuthors = books.map { it.author.trim() }.distinct().size
    val avgRating = if (books.isNotEmpty()) {
        books.map { it.rating }.average().toFloat()
    } else 8.5f

    // Top authors
    val authorCounts = books.groupingBy { it.author.trim() }.eachCount()
    val topAuthors = authorCounts.entries.sortedByDescending { it.value }.take(6)
    val maxAuthorCount = topAuthors.firstOrNull()?.value?.toFloat() ?: 1f

    // Genre distribution
    val genreCounts = books.groupingBy { it.genre.trim() }.eachCount()
    val sortedGenres = genreCounts.entries.sortedByDescending { it.value }

    var recommendationIndex by remember { mutableStateOf(0) }
    val recommendationsPool = listOf(
        listOf(
            Triple("সোনার কেল্লা", "সত্যজিৎ রায়", "ফেলুদা সিরিজ ও আপনার রহস্য পাঠরুচির সাথে নিখুঁত মিল।"),
            Triple("আরণ্যক", "বিভূতিভূষণ বন্দ্যোপাধ্যায়", "পথের পাঁচালী ও চাঁদের পাহাড় ভালো লাগলে এই মহাকাব্যিক প্রকৃতি-উপন্যাস আপনার জন্য।"),
            Triple("মার্ডার অন দ্য ওরিয়েন্ট এক্সপ্রেস", "আগাথা ক্রিস্টি", "আগাথা ক্রিস্টির বই ও পি. কে. বাসু কোর্টরুম থ্রিলার ভালো লাগলে এটি মাস্ট-রিড।")
        ),
        listOf(
            Triple("শাঁখামুটি", "সুনীল গঙ্গোপাধ্যায়", "কাকাবাবুর অভিযান ও রোমাঞ্চকর ভ্রমণ সাহিত্যের অনন্য নিদর্শন।"),
            Triple("নন্দিত নরকে", "হুমায়ূন আহমেদ", "হিমু ও মিসির আলির স্রষ্টার প্রথম সাড়াজাগানো মধ্যবিত্ত ট্র্যাজেডি।"),
            Triple("যখের ধন", "হেমেন্দ্রকুমার রায়", "অ্যাডভেঞ্চার ও বাংলা কিশোর ক্লাসিকের সেরা গুপ্তধন অভিযান।")
        )
    )

    val currentRecs = recommendationsPool[recommendationIndex % recommendationsPool.size]

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("stats_screen"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Metric Counters Row 1 & 2
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    MetricCard(
                        title = "মোট পড়া বই",
                        value = BengaliNumerals.toBn(totalBooks),
                        subtitle = "লাইব্রেরি ১০০% আপডেট",
                        icon = Icons.Default.Book,
                        iconTint = IndigoPrimary,
                        modifier = Modifier.weight(1f)
                    )
                    MetricCard(
                        title = "মোট পঠিত পৃষ্ঠা",
                        value = "${BengaliNumerals.toBn(totalPages)}+",
                        subtitle = "আনুমানিক ${BengaliNumerals.toBn(approxReadingHours)} ঘণ্টা পাঠ",
                        icon = Icons.Default.Description,
                        iconTint = EmeraldProgress,
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    MetricCard(
                        title = "পঠিত লেখক",
                        value = BengaliNumerals.toBn(uniqueAuthors),
                        subtitle = "দেশ-বিদেশের কালজয়ী লেখক",
                        icon = Icons.Default.Person,
                        iconTint = PurpleAccent,
                        modifier = Modifier.weight(1f)
                    )
                    MetricCard(
                        title = "গড় রেটিং",
                        value = BengaliNumerals.formatRatingBn(avgRating),
                        subtitle = "উচ্চমানের পাঠ-অভিজ্ঞতা",
                        icon = Icons.Default.Star,
                        iconTint = AmberRating,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Top Authors Bar Chart Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "👑 শীর্ষ লেখকবৃন্দ (সর্বাধিক পঠিত)",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        topAuthors.forEach { (author, count) ->
                            Column {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = author,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = "${BengaliNumerals.toBn(count)}টি",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = IndigoPrimary
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                LinearProgressIndicator(
                                    progress = { count / maxAuthorCount },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(6.dp),
                                    color = IndigoPrimary,
                                    trackColor = MaterialTheme.colorScheme.surfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }

        // Genre Breakdown Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "🧭 জনরা ও ক্যাটাগরি বিশ্লেষণ",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        sortedGenres.forEach { (genre, count) ->
                            Column {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = genre,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = "${BengaliNumerals.toBn(count)}টি",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = EmeraldProgress
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                LinearProgressIndicator(
                                    progress = { count.toFloat() / totalBooks.coerceAtLeast(1) },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(6.dp),
                                    color = EmeraldProgress,
                                    trackColor = MaterialTheme.colorScheme.surfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }

        // AI Recommendations Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "✨ পাঠরুচি অনুযায়ী স্মার্ট সাজেশন",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "আপনার পড়া বই ও ধারা বিশ্লেষণ করে তৈরি:",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        Button(
                            onClick = {
                                recommendationIndex++
                                onRefreshRecommendations()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = PurpleAccent),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.height(34.dp)
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("নতুন সাজেশন", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        currentRecs.forEach { (title, author, reason) ->
                            Card(
                                colors = CardDefaults.cardColors(
                                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                                ),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Text(
                                        text = title,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = "~ $author",
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "💡 $reason",
                                        fontSize = 11.sp,
                                        color = IndigoPrimary
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MetricCard(
    title: String,
    value: String,
    subtitle: String,
    icon: ImageVector,
    iconTint: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Box(
                    modifier = Modifier
                        .size(28.dp)
                        .background(iconTint.copy(alpha = 0.15f), RoundedCornerShape(8.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = iconTint,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = value,
                fontSize = 24.sp,
                fontWeight = FontWeight.ExtraBold,
                color = MaterialTheme.colorScheme.onSurface
            )

            Text(
                text = subtitle,
                fontSize = 10.sp,
                fontWeight = FontWeight.Medium,
                color = iconTint
            )
        }
    }
}

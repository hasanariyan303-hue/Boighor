package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.FormatQuote
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.BookEntity
import com.example.ui.theme.IndigoPrimary
import com.example.ui.theme.PurpleAccent

@Composable
fun QuotesScreen(
    books: List<BookEntity>,
    onShareCard: (BookEntity) -> Unit,
    onSaveQuote: (BookEntity, String) -> Unit,
    modifier: Modifier = Modifier
) {
    var showAddQuoteDialog by remember { mutableStateOf(false) }
    var selectedBookForQuote by remember { mutableStateOf<BookEntity?>(null) }
    var quoteInputText by remember { mutableStateOf("") }

    val quotedBooks = books.filter { !it.quote.isNullOrBlank() }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("quotes_screen"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Banner
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0x188B5CF6))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "✍️ স্মরণীয় উক্তি ও উদ্ধৃতি সংগ্রহ",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Button(
                            onClick = {
                                selectedBookForQuote = books.firstOrNull()
                                quoteInputText = ""
                                showAddQuoteDialog = true
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = PurpleAccent),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.height(34.dp)
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("নতুন উক্তি", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "বইগুলোর অমর বাণী ও প্রিয় অনুভূতি দিয়ে সোশ্যাল মিডিয়া ফটো কার্ড তৈরি করে শেয়ার করুন।",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        if (quotedBooks.isEmpty()) {
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 40.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Default.FormatQuote,
                        contentDescription = null,
                        modifier = Modifier.size(48.dp),
                        tint = Color.Gray
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "কোনো স্মরণীয় উক্তি যোগ করা হয়নি।",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "যেকোনো বই ওপেন করে অথবা উপরের বাটনে ক্লিক করে উক্তি যোগ করুন!",
                        fontSize = 11.sp,
                        color = Color.Gray
                    )
                }
            }
        } else {
            items(quotedBooks, key = { it.id }) { book ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.Top) {
                            Icon(
                                imageVector = Icons.Default.FormatQuote,
                                contentDescription = null,
                                tint = PurpleAccent,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "\"${book.quote}\"",
                                fontSize = 13.sp,
                                fontStyle = FontStyle.Italic,
                                color = MaterialTheme.colorScheme.onSurface,
                                lineHeight = 19.sp
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        HorizontalDivider(color = Color(0x15000000))
                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = book.title,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "~ ${book.author}",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            Button(
                                onClick = { onShareCard(book) },
                                colors = ButtonDefaults.buttonColors(containerColor = IndigoPrimary),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.height(32.dp)
                            ) {
                                Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(12.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("কার্ড শেয়ার", fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddQuoteDialog) {
        var bookSearchQuery by remember { mutableStateOf("") }
        val matchingBooks = books.filter {
            it.title.contains(bookSearchQuery, ignoreCase = true) || it.author.contains(bookSearchQuery, ignoreCase = true)
        }.take(5)

        AlertDialog(
            onDismissRequest = { showAddQuoteDialog = false },
            title = { Text("নতুন উক্তি যোগ করুন", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("কোন বইটির উক্তি যোগ করতে চান?", fontSize = 12.sp)

                    OutlinedTextField(
                        value = bookSearchQuery,
                        onValueChange = { bookSearchQuery = it },
                        placeholder = { Text("বইয়ের নাম দিয়ে খুঁজুন...", fontSize = 12.sp) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    if (selectedBookForQuote != null) {
                        Text(
                            text = "নির্বাচিত: ${selectedBookForQuote?.title} (~ ${selectedBookForQuote?.author})",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = IndigoPrimary
                        )
                    }

                    if (matchingBooks.isNotEmpty()) {
                        Column {
                            matchingBooks.forEach { b ->
                                TextButton(
                                    onClick = { selectedBookForQuote = b },
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(
                                        text = "${b.title} (~ ${b.author})",
                                        fontSize = 11.sp,
                                        color = if (selectedBookForQuote?.id == b.id) IndigoPrimary else Color.Gray
                                    )
                                }
                            }
                        }
                    }

                    OutlinedTextField(
                        value = quoteInputText,
                        onValueChange = { quoteInputText = it },
                        label = { Text("প্রিয় উক্তিটি লিখুন") },
                        maxLines = 4,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val book = selectedBookForQuote
                        if (book != null && quoteInputText.isNotBlank()) {
                            onSaveQuote(book, quoteInputText.trim())
                            showAddQuoteDialog = false
                        }
                    }
                ) {
                    Text("সংরক্ষণ")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddQuoteDialog = false }) {
                    Text("বাতিল")
                }
            }
        )
    }
}

package com.example.util

import java.util.Locale

object BengaliNumerals {
    private val bnDigits = charArrayOf('০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯')
    private val supDigits = charArrayOf('⁰', '¹', '²', '³', '⁴', '⁵', '⁶', '⁷', '⁸', '⁹')

    fun toBn(num: Int): String = toBn(num.toString())
    fun toBn(num: Long): String = toBn(num.toString())

    fun toBn(str: String): String {
        val sb = StringBuilder()
        for (ch in str) {
            if (ch in '0'..'9') {
                sb.append(bnDigits[ch - '0'])
            } else {
                sb.append(ch)
            }
        }
        return sb.toString()
    }

    fun toSup(str: String?): String {
        if (str.isNullOrEmpty()) return ""
        val sb = StringBuilder()
        for (ch in str) {
            if (ch in '0'..'9') {
                sb.append(supDigits[ch - '0'])
            } else {
                sb.append(ch)
            }
        }
        return sb.toString()
    }

    fun formatRatingBn(rating: Float): String {
        val clamped = rating.coerceIn(1.0f, 10.0f)
        val formatted = String.format(Locale.US, "%.1f", clamped)
        return toBn(formatted)
    }

    fun getRatingVerdict(rating: Float): String {
        return when {
            rating >= 9.3f -> "কালজয়ী মাস্টারপিস (Masterpiece)"
            rating >= 8.5f -> "অসাধারণ (Must Read)"
            rating >= 7.5f -> "খুবই ভালো (Very Good)"
            rating >= 6.0f -> "ভালো (Good)"
            else -> "মোটামুটি (Average)"
        }
    }

    fun formatPageCountBadge(pages: Int): String {
        return if (pages > 0) "${toBn(pages)} পৃষ্ঠা" else "— পৃষ্ঠা"
    }
}

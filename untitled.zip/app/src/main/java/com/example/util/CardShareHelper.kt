package com.example.util

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.widget.Toast
import androidx.core.content.FileProvider
import com.example.data.local.BookEntity
import java.io.File
import java.io.FileOutputStream

object CardShareHelper {

    fun copyQuoteText(context: Context, book: BookEntity) {
        val quoteText = book.quote ?: "${book.title} — বাংলা সাহিত্যের এক অনন্য সৃষ্টি।"
        val text = "📖 আমি পড়ছি: ${book.title} (~ ${book.author})\n\n\"$quoteText\"\n\n#বইঘর #Boighor #ReadingTracker"
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText("Boighor Quote", text)
        clipboard.setPrimaryClip(clip)
        Toast.makeText(context, "উক্তিটি ক্লিপবোর্ডে কপি করা হয়েছে!", Toast.LENGTH_SHORT).show()
    }

    fun shareCardImage(context: Context, book: BookEntity) {
        try {
            val bitmap = renderCardBitmap(book)
            val cacheDir = File(context.cacheDir, "shared_cards")
            if (!cacheDir.exists()) cacheDir.mkdirs()

            val file = File(cacheDir, "boighor_quote_${book.id}.png")
            FileOutputStream(file).use { out ->
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
            }

            val uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )

            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "image/png"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, "বইঘর — ${book.title}")
                putExtra(Intent.EXTRA_TEXT, "📖 ${book.title} (~ ${book.author})\n#বইঘর #BooksIHaveRead")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }

            context.startActivity(Intent.createChooser(shareIntent, "সোশ্যাল কার্ড শেয়ার করুন"))
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(context, "কার্ড শেয়ার করতে সমস্যা হয়েছে", Toast.LENGTH_SHORT).show()
        }
    }

    private fun renderCardBitmap(book: BookEntity): Bitmap {
        val width = 1080
        val height = 1350
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        // Background Gradient
        val bgPaint = Paint().apply {
            shader = LinearGradient(
                0f, 0f, width.toFloat(), height.toFloat(),
                Color.parseColor("#1E1B4B"), // Deep indigo
                Color.parseColor("#090D16"), // Near black
                Shader.TileMode.CLAMP
            )
        }
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)

        // Inner frame with subtle rounded border
        val borderPaint = Paint().apply {
            color = Color.parseColor("#312E81")
            style = Paint.Style.STROKE
            strokeWidth = 4f
            isAntiAlias = true
        }
        canvas.drawRoundRect(RectF(40f, 40f, width - 40f, height - 40f), 48f, 48f, borderPaint)

        // Brand Pill Top Left
        val pillPaint = Paint().apply {
            color = Color.parseColor("#3730A3")
            isAntiAlias = true
        }
        canvas.drawRoundRect(RectF(80f, 80f, 440f, 150f), 35f, 35f, pillPaint)

        val brandTextPaint = TextPaint().apply {
            color = Color.parseColor("#FDE047") // Gold
            textSize = 34f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }
        canvas.drawText("BOIGHOR • বইঘর", 120f, 126f, brandTextPaint)

        // Rating Badge Top Right
        val ratingBadgePaint = Paint().apply {
            color = Color.parseColor("#F59E0B")
            isAntiAlias = true
        }
        canvas.drawRoundRect(RectF(width - 320f, 80f, width - 80f, 150f), 35f, 35f, ratingBadgePaint)

        val ratingTextPaint = TextPaint().apply {
            color = Color.parseColor("#0F172A")
            textSize = 36f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }
        val ratingStr = "★ ${BengaliNumerals.formatRatingBn(book.rating)}/১০"
        canvas.drawText(ratingStr, width - 290f, 126f, ratingTextPaint)

        // Book Cover Artwork Box in the Center
        val coverLeft = (width / 2f) - 150f
        val coverTop = 230f
        val coverRight = coverLeft + 300f
        val coverBottom = coverTop + 420f

        val coverBgPaint = Paint().apply {
            shader = LinearGradient(
                coverLeft, coverTop, coverRight, coverBottom,
                Color.parseColor("#4F46E5"),
                Color.parseColor("#0F172A"),
                Shader.TileMode.CLAMP
            )
            isAntiAlias = true
        }
        canvas.drawRoundRect(RectF(coverLeft, coverTop, coverRight, coverBottom), 24f, 24f, coverBgPaint)

        // Spine bar on cover
        val spinePaint = Paint().apply {
            color = Color.argb(90, 255, 255, 255)
            isAntiAlias = true
        }
        canvas.drawRect(coverLeft, coverTop, coverLeft + 20f, coverBottom, spinePaint)

        // Book Number badge on cover
        val bookNumPaint = TextPaint().apply {
            color = Color.WHITE
            textSize = 38f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }
        canvas.drawText("#${BengaliNumerals.toBn(book.id)}", coverLeft + 40f, coverTop + 70f, bookNumPaint)

        // Title on Cover
        val coverTitlePaint = TextPaint().apply {
            color = Color.WHITE
            textSize = 36f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }
        canvas.drawText(book.title.take(14), coverLeft + 35f, coverBottom - 60f, coverTitlePaint)

        // Title & Author below cover
        val titlePaint = TextPaint().apply {
            color = Color.WHITE
            textSize = 58f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText(book.title, width / 2f, 740f, titlePaint)

        val authorPaint = TextPaint().apply {
            color = Color.parseColor("#94A3B8")
            textSize = 38f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            isAntiAlias = true
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText("~ ${book.author}", width / 2f, 800f, authorPaint)

        // Quote Section with stylized quotes
        val quote = book.quote ?: "একটি ভালো বই মানুষের জীবন বদলে দেওয়ার শক্তি রাখে।"
        val quotePaint = TextPaint().apply {
            color = Color.parseColor("#E2E8F0")
            textSize = 40f
            typeface = Typeface.create(Typeface.SERIF, Typeface.ITALIC)
            isAntiAlias = true
        }

        val quoteWidth = width - 240
        val staticLayout = StaticLayout.Builder
            .obtain("\"$quote\"", 0, quote.length + 2, quotePaint, quoteWidth)
            .setAlignment(Layout.Alignment.ALIGN_CENTER)
            .setLineSpacing(12f, 1f)
            .build()

        canvas.save()
        canvas.translate(120f, 870f)
        staticLayout.draw(canvas)
        canvas.restore()

        // Bottom Footer Bar
        val dividerPaint = Paint().apply {
            color = Color.parseColor("#334155")
            strokeWidth = 2f
        }
        canvas.drawLine(100f, 1200f, width - 100f, 1200f, dividerPaint)

        val footerPagesPaint = TextPaint().apply {
            color = Color.parseColor("#94A3B8")
            textSize = 32f
            isAntiAlias = true
        }
        canvas.drawText("${BengaliNumerals.formatPageCountBadge(book.pages)} • পড়া শেষ", 100f, 1260f, footerPagesPaint)

        val footerHashPaint = TextPaint().apply {
            color = Color.parseColor("#818CF8")
            textSize = 32f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
            textAlign = Paint.Align.RIGHT
        }
        canvas.drawText("#BooksIHaveRead", width - 100f, 1260f, footerHashPaint)

        return bitmap
    }
}

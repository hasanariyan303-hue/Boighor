package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface BookDao {
    @Query("SELECT * FROM books ORDER BY id ASC")
    fun getAllBooks(): Flow<List<BookEntity>>

    @Query("SELECT * FROM books WHERE id = :id LIMIT 1")
    suspend fun getBookById(id: Int): BookEntity?

    @Query("SELECT COUNT(*) FROM books")
    suspend fun getBookCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBooks(books: List<BookEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBook(book: BookEntity)

    @Update
    suspend fun updateBook(book: BookEntity)

    @Delete
    suspend fun deleteBook(book: BookEntity)

    @Query("DELETE FROM books WHERE id = :id")
    suspend fun deleteBookById(id: Int)

    // Clear currently reading flags
    @Query("UPDATE books SET isCurrentlyReading = 0")
    suspend fun clearCurrentlyReading()

    @Query("UPDATE books SET isCurrentlyReading = 1 WHERE id = :id")
    suspend fun setCurrentlyReading(id: Int)

    @Query("UPDATE books SET currentProgress = :progress WHERE id = :id")
    suspend fun updateBookProgress(id: Int, progress: Int)

    @Query("UPDATE books SET favorite = NOT favorite WHERE id = :id")
    suspend fun toggleFavorite(id: Int)

    // Bucket list operations
    @Query("SELECT * FROM bucket_list ORDER BY id DESC")
    fun getAllBucketBooks(): Flow<List<BucketBookEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBucketBook(book: BucketBookEntity)

    @Query("DELETE FROM bucket_list WHERE id = :id")
    suspend fun deleteBucketBookById(id: Long)

    @Query("DELETE FROM books")
    suspend fun deleteAllBooks()
}

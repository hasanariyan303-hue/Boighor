package com.example.data.repository

import com.example.data.local.BookDao
import com.example.data.local.BookEntity
import com.example.data.local.BucketBookEntity
import com.example.data.local.DefaultBooksData
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

class BoighorRepository(private val bookDao: BookDao) {

    val allBooks: Flow<List<BookEntity>> = bookDao.getAllBooks()
    val allBucketBooks: Flow<List<BucketBookEntity>> = bookDao.getAllBucketBooks()

    suspend fun ensureInitialData() = withContext(Dispatchers.IO) {
        if (bookDao.getBookCount() == 0) {
            bookDao.insertBooks(DefaultBooksData.getInitialBooks())
        }
    }

    suspend fun getBookById(id: Int): BookEntity? = withContext(Dispatchers.IO) {
        bookDao.getBookById(id)
    }

    suspend fun insertBook(book: BookEntity) = withContext(Dispatchers.IO) {
        bookDao.insertBook(book)
    }

    suspend fun updateBook(book: BookEntity) = withContext(Dispatchers.IO) {
        bookDao.updateBook(book)
    }

    suspend fun deleteBookById(id: Int) = withContext(Dispatchers.IO) {
        bookDao.deleteBookById(id)
    }

    suspend fun setCurrentlyReading(id: Int) = withContext(Dispatchers.IO) {
        bookDao.clearCurrentlyReading()
        bookDao.setCurrentlyReading(id)
    }

    suspend fun updateBookProgress(id: Int, progress: Int) = withContext(Dispatchers.IO) {
        bookDao.updateBookProgress(id, progress)
    }

    suspend fun toggleFavorite(id: Int) = withContext(Dispatchers.IO) {
        bookDao.toggleFavorite(id)
    }

    suspend fun insertBucketBook(bucketBook: BucketBookEntity) = withContext(Dispatchers.IO) {
        bookDao.insertBucketBook(bucketBook)
    }

    suspend fun deleteBucketBookById(id: Long) = withContext(Dispatchers.IO) {
        bookDao.deleteBucketBookById(id)
    }

    suspend fun exportToCsv(books: List<BookEntity>): String = withContext(Dispatchers.Default) {
        val sb = StringBuilder()
        sb.append("ID,Title,Author,Genre,Series,Pages,Rating,Favorite,Quote\n")
        for (b in books) {
            val titleEsc = b.title.replace("\"", "\"\"")
            val authorEsc = b.author.replace("\"", "\"\"")
            val genreEsc = b.genre.replace("\"", "\"\"")
            val seriesEsc = (b.series ?: "").replace("\"", "\"\"")
            val quoteEsc = (b.quote ?: "").replace("\"", "\"\"")
            sb.append("${b.id},\"$titleEsc\",\"$authorEsc\",\"$genreEsc\",\"$seriesEsc\",${b.pages},${b.rating},${b.favorite},\"$quoteEsc\"\n")
        }
        sb.toString()
    }

    suspend fun exportToJson(books: List<BookEntity>, goal: Int): String = withContext(Dispatchers.Default) {
        val root = JSONObject()
        root.put("app", "বইঘর")
        root.put("readingGoal", goal)
        val arr = JSONArray()
        for (b in books) {
            val obj = JSONObject()
            obj.put("id", b.id)
            obj.put("title", b.title)
            obj.put("author", b.author)
            obj.put("genre", b.genre)
            if (b.series != null) obj.put("series", b.series)
            if (b.seriesNum != null) obj.put("seriesNum", b.seriesNum)
            obj.put("pages", b.pages)
            obj.put("rating", b.rating.toDouble())
            obj.put("favorite", b.favorite)
            if (b.quote != null) obj.put("quote", b.quote)
            obj.put("plot", b.plot)
            obj.put("isCurrentlyReading", b.isCurrentlyReading)
            obj.put("currentProgress", b.currentProgress)
            arr.put(obj)
        }
        root.put("books", arr)
        root.toString(2)
    }

    suspend fun restoreFromJson(jsonString: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val root = JSONObject(jsonString)
            if (!root.has("books")) return@withContext false
            val arr = root.getJSONArray("books")
            val list = mutableListOf<BookEntity>()
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                list.add(
                    BookEntity(
                        id = obj.optInt("id", i + 1),
                        title = obj.optString("title", "বই"),
                        author = obj.optString("author", "অজ্ঞাত"),
                        genre = obj.optString("genre", "উপন্যাস"),
                        series = if (obj.has("series") && !obj.isNull("series")) obj.getString("series") else null,
                        seriesNum = if (obj.has("seriesNum") && !obj.isNull("seriesNum")) obj.getString("seriesNum") else null,
                        pages = obj.optInt("pages", 0),
                        rating = obj.optDouble("rating", 8.5).toFloat(),
                        favorite = obj.optBoolean("favorite", false),
                        quote = if (obj.has("quote") && !obj.isNull("quote")) obj.getString("quote") else null,
                        plot = obj.optString("plot", ""),
                        isCurrentlyReading = obj.optBoolean("isCurrentlyReading", false),
                        currentProgress = obj.optInt("currentProgress", 0)
                    )
                )
            }
            if (list.isNotEmpty()) {
                bookDao.deleteAllBooks()
                bookDao.insertBooks(list)
                true
            } else {
                false
            }
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }
}

package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "books")
data class BookEntity(
    @PrimaryKey val id: Int,
    val title: String,
    val author: String,
    val genre: String,
    val series: String? = null,
    val seriesNum: String? = null,
    val pages: Int = 0,
    val rating: Float = 8.5f,
    val favorite: Boolean = false,
    val quote: String? = null,
    val plot: String = "",
    val isCurrentlyReading: Boolean = false,
    val currentProgress: Int = 0
)

@Entity(tableName = "bucket_list")
data class BucketBookEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val title: String,
    val author: String,
    val pages: Int = 0,
    val genre: String = "উপন্যাস",
    val rating: Float = 8.5f
)

package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(entities = [BookEntity::class, BucketBookEntity::class], version = 1, exportSchema = false)
abstract class BoighorDatabase : RoomDatabase() {
    abstract fun bookDao(): BookDao

    companion object {
        @Volatile
        private var INSTANCE: BoighorDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): BoighorDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    BoighorDatabase::class.java,
                    "boighor_database"
                )
                    .addCallback(DatabaseCallback(scope))
                    .build()
                INSTANCE = instance
                instance
            }
        }

        private class DatabaseCallback(
            private val scope: CoroutineScope
        ) : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    scope.launch(Dispatchers.IO) {
                        populateInitialData(database.bookDao())
                    }
                }
            }

            suspend fun populateInitialData(bookDao: BookDao) {
                if (bookDao.getBookCount() == 0) {
                    bookDao.insertBooks(DefaultBooksData.getInitialBooks())
                }
            }
        }
    }
}
